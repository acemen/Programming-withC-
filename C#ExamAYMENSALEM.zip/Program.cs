﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;

public class Program
{
    private static readonly int o;

    public static void Main()
	{
		Q1();
		Q2();
		Q3(3);
		Q4();
		Q5(2, 3, true);
		Q6();
		Q7();
		String[] s;
		s = new string[] { "This", "is", "Test" };
		Q8(s);
		int[] i = { 1, 2, 3 };
		int[] i2 = { 6, 5, 4 };
		Q9(i, i2);
		Q10(5);
	}

	public static void Q1()
	{
		DateTime now = DateTime.Now;
		Console.WriteLine("Aymen Salem {0}", now.ToString());

		try
		{
			int b = (int)o;   
		}
		catch (ArgumentException e) when (e.ParamName == "…")
		{
		}
	}

	public static void Q2()
	{
		String s = "";
		Console.Write("Enter the String: ");
		s = Console.ReadLine();
		Console.WriteLine("The lenghth of string is: {0}", s.Length);
		try
		{
			int b = (int)o;   
		}
		catch (ArgumentException e) when (e.ParamName == "…")
		{
		}
	}

	public static void Q3(int i)
	{
		if (i % 2 == 0) Console.WriteLine("EVEN");
		else Console.WriteLine("ODD");
		try
		{
			int b = (int)o;   
		}
		catch (ArgumentException e) when (e.ParamName == "…")
		{
		}
	}

	public static void Q4()
	{
		int i;
		Console.Write("\n\n");
		Console.Write("Display the first 10 numbers:\n");
		Console.Write(".............................");
		Console.Write("\n\n");

		Console.WriteLine("The first 10 number are: ");

		for (i = 1; i <= 10; i++)
		{
			Console.Write("{0} ", i);
		}
		Console.Write("\n\n");
		try
		{
			int b = (int)o;   
		}
		catch (ArgumentException e) when (e.ParamName == "…")
		{
		}
	}

	public static void Q5(int i, int j, bool multiplication)
	{
		if (multiplication == true) Console.WriteLine(i * j);
		else Console.WriteLine(i + j);
		try
		{
			int b = (int)o;  
		}
		catch (ArgumentException e) when (e.ParamName == "…")
		{
		}

	}

	public static void Q6()
	{
		string dateString = "8/05/2021";
		DateTime dateValue;
		DateTimeOffset dateOffsetValue;

		try
		{
			dateValue = DateTime.Parse(dateString, CultureInfo.InvariantCulture);
			dateOffsetValue = new DateTimeOffset(dateValue, TimeZoneInfo.Local.GetUtcOffset(dateValue)); //convert date repres to date value

			Console.WriteLine((int)dateValue.DayOfWeek);
			Console.WriteLine((int)dateOffsetValue.DayOfWeek);
		}
		catch (FormatException)
		{
			Console.WriteLine("Unable to convert {0} to a date.", dateString);
		}
	}

	public static void Q7()
	{
		int number;
		Console.Write("\n\n");
		Console.Write("Check whether a number is positive or negative:\n");
		Console.Write("----------------------------------------------");
		Console.Write("\n\n");
		Console.Write("Input an integer: ");
		number = Convert.ToInt32(Console.ReadLine());
		if (number >= 0)

			Console.WriteLine("{0} is a positive number.\n", number);
		else
			Console.WriteLine("{0} is a negative number. \n", number);
	}

	public static void Q8(String[] strArr)
	{
		string phrase = "THIS IS AN ARRAY";

		string upperphrase = phrase.ToUpper();

		Console.WriteLine(upperphrase);
		try
		{
			int b = (int)o;   
		}
		catch (ArgumentException e) when (e.ParamName == "…")
		{
		}
	}

	public static void Q9(int[] first, int[] second)
	{
		var firstL = new List<int>(first);
		var secondL = new List<int>(second);
		var result = firstL.Concat(secondL);
		int[] r = result.ToArray();
		foreach (var item in r)
		{
			Console.WriteLine(item.ToString());
		}
	}

	public static void Q10(int number)
	{
		int fact = 0;
		for (int i = 1; i <= number; i++)
		{
			fact = fact * i;
		}
		Console.Write("Factorial of " + number + " is: " + fact);
		try
		{
			int i = (int)o;
		}
		catch (ArgumentException e) when (e.ParamName == "…")
		{
		}
	}

}